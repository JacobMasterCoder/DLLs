﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace QuorumAPI
{
    public static class QuorumAPI
    {
        [DllImport(@"bin\Xeno.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void Initialize();

        [DllImport(@"bin\Xeno.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void Attach();

        [DllImport(@"bin\Xeno.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr GetClients();

        [DllImport(@"bin\Xeno.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern void SetSettings(APISetting settingID, int value);

        [DllImport(@"bin\Xeno.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        private static extern void Execute(byte[] scriptSource, string[] clientUsers, int numUsers);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct ClientInfo
        {
            public string version;
            public string name;
            public int id;
        }

        private static bool _autoInject = false;

        public static void SetAutoInject(bool enable)
        {
            Initialize();
            _autoInject = enable;
            SetSettings(APISetting.AutoAttach, enable ? 1 : 0);
        }

        public static bool IsAutoInjectEnabled()
        {
            return _autoInject;
        }
        public static void AttachAPI()
        {
            Initialize();
            Attach();
            Thread.Sleep(1000);

            string QuorumScript = "\tgame:GetService(\"StarterGui\"):SetCore(\"SendNotification\", {\r\n\t\tTitle = \"[Quorum]\",\r\n\t\tText = \"Attached. Thanks for using Quorum API!\"\r\n\t})";
            var clients = GetClientsList();
            var clientUsers = clients.Select(c => c.name).ToArray();
            Execute(Encoding.UTF8.GetBytes(QuorumScript), clientUsers, clientUsers.Length);
        }

        public static int AttachAPIWithState()
        {
            Initialize();
            Attach();
            Thread.Sleep(4000);

            var clients = GetClientsList();
            if (clients.Count > 0)
            {
                string QuorumScript = "\tgame:GetService(\"StarterGui\"):SetCore(\"SendNotification\", {\r\n\t\tTitle = \"[Quorum]\",\r\n\t\tText = \"Attached. Thanks for using Quorum API!\"\r\n\t})";
                var clientUsers = clients.Select(c => c.name).ToArray();
                Execute(Encoding.UTF8.GetBytes(QuorumScript), clientUsers, clientUsers.Length);
                return 1;
            }
            return 0;
        }
        public static void ExecuteScript(string scriptSource)
        {
            var clients = GetClientsList();
            var clientUsers = clients.Select(c => c.name).ToArray();
            Execute(Encoding.UTF8.GetBytes(scriptSource), clientUsers, clientUsers.Length);
        }

        public static bool IsRobloxOpen()
        {
            return Process.GetProcessesByName("RobloxPlayerBeta").Length > 0;
        }

        public static void KillRoblox()
        {
            if (IsRobloxOpen())
            {
                var processes = Process.GetProcessesByName("RobloxPlayerBeta");
                foreach (var process in processes)
                {
                    process.Kill();
                }
            }
        }
        public static List<ClientInfo> GetClientsList()
        {
            var clients = new List<ClientInfo>();
            IntPtr currentPtr = GetClients();
            while (true)
            {
                var client = Marshal.PtrToStructure<ClientInfo>(currentPtr);
                if (client.name == null) break;
                clients.Add(client);
                currentPtr += Marshal.SizeOf<ClientInfo>();
            }
            return clients;
        }

        public static int GetAttachState()
        {
            try
            {
                var clients = GetClientsList();
                return clients.Count > 0 ? 1 : 0;
            }
            catch
            {
                return 0;
            }
        }

        public enum APISetting
        {
            AutoAttach = 1,
        }
    }
}